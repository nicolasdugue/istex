public class cluster {
	public  double[] featureVector;
	public int nLabels;
	public int nDocs;
}
