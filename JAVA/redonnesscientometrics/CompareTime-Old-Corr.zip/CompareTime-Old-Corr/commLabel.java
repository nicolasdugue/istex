public class commLabel {
	String name;
	int index;
	double fMeasure_source;
	double fMeasure_target;
	int cluster_src;
	int cluster_trg;
}
