public class label {
	
	String name;
	double val_source;
	double val_target;
	int index;
	int cluster_src;
	int cluster_trg;
	label next;
	
}
